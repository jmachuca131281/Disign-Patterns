package org.formacion.abstractfactory;

public interface Saludos {

	String buenosDias();
	
	String buenasTardes();
	
}
