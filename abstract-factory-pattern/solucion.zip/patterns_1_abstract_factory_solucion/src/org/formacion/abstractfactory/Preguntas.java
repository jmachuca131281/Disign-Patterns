package org.formacion.abstractfactory;

public interface Preguntas {

	String preguntaHora();
	
	String preguntaTiempo();
}
